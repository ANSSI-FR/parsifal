struct s = {
  x : uint8;
  parse_field y : copy(x+1);
}
