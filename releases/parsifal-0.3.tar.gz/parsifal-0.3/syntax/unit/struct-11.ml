struct s [parse_param n] = {
  x : uint8;
  l : list(PARSE n) of uint16;
}
