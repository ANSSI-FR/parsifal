struct s = {
  x : uint8;
  dump_checkpoint y : debug_dump;
}
