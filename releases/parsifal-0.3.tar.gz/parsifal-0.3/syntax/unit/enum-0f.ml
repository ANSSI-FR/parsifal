enum test [little_endian] (24, Exception) =
  | 0 -> A
  | 1 -> B
  | 2 -> C
  | 3 -> D
