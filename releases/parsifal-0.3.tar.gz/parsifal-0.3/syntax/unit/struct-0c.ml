struct s = {
  x : uint8;
  parse_checkpoint : save_offset;
}
