struct s = {
  x : uint8;
  parse_checkpoint y : save_offset;
}
