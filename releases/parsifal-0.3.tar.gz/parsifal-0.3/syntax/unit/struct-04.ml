struct s [param n] = {
  x : uint8;
  l : list(n) of uint16;
}
