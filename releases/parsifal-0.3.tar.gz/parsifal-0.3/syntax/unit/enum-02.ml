enum test (8, UnknownVal U) =
  | 0 -> A
  | 1 -> B
  | 2 -> C
  | 3 -> D
