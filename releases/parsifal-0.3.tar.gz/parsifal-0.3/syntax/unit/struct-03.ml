struct s [top] = {
  x : uint8;
  y : uint16;
}
