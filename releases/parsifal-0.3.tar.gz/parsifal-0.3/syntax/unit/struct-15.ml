struct s = {
  x : custom [BOTH a; b];
}
