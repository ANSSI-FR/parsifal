struct s = {
  s : string;
  x : uint8;
}
