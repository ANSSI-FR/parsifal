struct s = {
  x : uint8;
}
