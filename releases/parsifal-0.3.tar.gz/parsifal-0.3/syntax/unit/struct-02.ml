struct s = {
  x : uint8;
  y : uint16;
}
