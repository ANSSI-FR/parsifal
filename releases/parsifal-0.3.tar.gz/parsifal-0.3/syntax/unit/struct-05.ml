struct s [param n; param m] = {
  x : uint8;
  l : list(n) of uint16;
  sl : list(m) of string(4);
}
