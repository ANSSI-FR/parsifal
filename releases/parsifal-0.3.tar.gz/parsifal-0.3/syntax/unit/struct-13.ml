struct s [both_param n] = {
  x : custom(BOTH n);
}
