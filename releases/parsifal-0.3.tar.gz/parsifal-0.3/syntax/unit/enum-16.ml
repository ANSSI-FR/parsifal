enum test (8, Exception) =
  | 0, 2 -> A
  | 3 -> B
