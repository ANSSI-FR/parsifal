enum test (1, Exception) =
  | 0 -> A
  | 1 -> B
