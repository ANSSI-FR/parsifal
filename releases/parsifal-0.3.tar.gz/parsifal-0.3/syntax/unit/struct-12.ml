struct s [dump_param n] = {
  x : uint8;
  y : custom(DUMP n);
}
