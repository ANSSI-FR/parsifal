struct s [param n; param n] = {
  x : uint8;
  l : list(n) of uint16;
  sl : list(n) of string(4);
}
