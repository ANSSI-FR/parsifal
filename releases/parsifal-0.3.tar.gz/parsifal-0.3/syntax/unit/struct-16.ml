struct s = {
  x : custom [CONTEXT uint48];
}
