struct s = {
  x : uint8;
  x : string;
}
