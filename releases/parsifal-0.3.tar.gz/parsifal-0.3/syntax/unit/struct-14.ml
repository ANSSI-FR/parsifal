struct s [both_param n] = {
  x : custom[n] of uint8;
}
