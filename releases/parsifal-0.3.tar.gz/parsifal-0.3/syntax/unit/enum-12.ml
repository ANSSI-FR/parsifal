enum test (8, Exception) =
  | 0 -> A
  | 0x1 -> B
  | 0o2 -> C
  | 0b11 -> D
