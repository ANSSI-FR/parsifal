enum test (8, Exception) =
  | 0 -> A, "First constructor A"
  | 1 -> B, "BBB"
  | 2 -> C
  | 3 -> A
