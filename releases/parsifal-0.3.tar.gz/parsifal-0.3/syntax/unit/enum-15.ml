enum test (8, Exception) =
  | 0 | 3 -> A
  | 1 -> B
  | 2 -> C

