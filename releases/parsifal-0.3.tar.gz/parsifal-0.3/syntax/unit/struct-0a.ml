struct s = {
  x : uint8;
  optional y : uint16;
}
