struct s = {
  x : uint8;
  dump_checkpoint : debug_dump;
}
