struct s [param n] = {
  x : uint8;
  y : uint16;
}
