enum test (8, Exception) =
  | 0 -> A
