struct s = {
  x : uint8;
  dump_arg x;
  y : nt_string[x];
}
